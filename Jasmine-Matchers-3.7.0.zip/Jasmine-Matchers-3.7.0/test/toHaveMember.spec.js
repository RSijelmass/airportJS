// modules
const describeToHaveX = require('./lib/describeToHaveX');

// spec
describe('toHaveMember', () => {
  describeToHaveX('toHaveMember', () => {});
});
