// modules
const toBeBefore = require('./toBeBefore');

// public
module.exports = (otherDate, actual) => toBeBefore(actual, otherDate);
