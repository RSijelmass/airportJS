// modules
const toBeArrayOfSize = require('./toBeArrayOfSize');

// public
module.exports = actual => toBeArrayOfSize(0, actual);
