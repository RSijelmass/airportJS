// modules
const is = require('./lib/is');

// public
module.exports = is.Function;
