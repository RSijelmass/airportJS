// public
module.exports = actual => actual === '';
